# Input files

These are the two primary source files supplied for the project:

- `xc7a200tffg1156pkg.csv` — official package pin database used as the pinout reference.
- `XC7A200T-2FFG1156C.xml` — original Cadence/OrCAD XML used as the starting library source.
- `XC7A200T-FFG1156_Cadence17x_source_package.zip` — earlier source package collected during the project.

The CSV is the authoritative source for package-ball identity and the NC column during the comparison workflow.
