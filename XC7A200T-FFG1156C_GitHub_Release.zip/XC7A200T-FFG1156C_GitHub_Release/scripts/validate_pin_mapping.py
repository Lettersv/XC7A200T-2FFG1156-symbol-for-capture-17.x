#!/usr/bin/env python3
"""Validate the package-ball/name mapping between the AMD CSV and an OrCAD XML.

Usage:
    python validate_pin_mapping.py package.csv symbol.xml --report report.csv

The XML is treated as a 1,156-pin OrCAD library. Physical pin numbers are read
from PhysicalPart/PinNumber and symbol pins from SymbolPinScalar/Defn position.
The script also checks that pins named NC in the CSV have IsNoConnect=1.
"""
from __future__ import annotations
import argparse, csv, json, re
import xml.etree.ElementTree as ET
from pathlib import Path


def load_csv(path: Path):
    rows = []
    with path.open(newline='', encoding='utf-8-sig') as f:
        r = csv.reader(f)
        all_rows = list(r)
    header_i = next(i for i,row in enumerate(all_rows) if row[:2] == ['Pin','Pin Name'])
    header = all_rows[header_i]
    idx = {name:i for i,name in enumerate(header) if name}
    for row in all_rows[header_i+1:]:
        if not row or not row[0] or row[0].startswith('('):
            continue
        pin, name = row[0].strip(), row[1].strip()
        # Package balls are letter+digits; exclude summary rows.
        if not re.fullmatch(r'[A-Z]{1,3}[0-9]{1,3}', pin):
            continue
        rows.append({
            'ball': pin,
            'name': name,
            'bank': row[idx['Bank']].strip() if idx.get('Bank') is not None and len(row)>idx['Bank'] else '',
            'io_type': row[idx['I/O Type']].strip() if idx.get('I/O Type') is not None and len(row)>idx['I/O Type'] else '',
            'nc': row[idx['No-Connect']].strip() if idx.get('No-Connect') is not None and len(row)>idx['No-Connect'] else '',
        })
    return rows


def parse_xml(path: Path):
    root = ET.parse(path).getroot()
    # Find the first PhysicalPart and all symbol pins under its associated NormalView.
    pkg = root.find('.//Package')
    if pkg is None:
        raise ValueError('Package not found')
    normal = pkg.find('.//NormalView')
    physical = pkg.find('.//PhysicalPart')
    if normal is None or physical is None:
        raise ValueError('NormalView/PhysicalPart not found')
    pins = []
    for p in normal.findall('.//SymbolPinScalar'):
        d = p.find('Defn')
        if d is not None:
            pins.append({k:v for k,v in d.attrib.items()})
    physical_pins = []
    for p in physical.findall('./PinNumber/Defn'):
        physical_pins.append({k:v for k,v in p.attrib.items()})
    return root, pins, physical_pins


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('csv')
    ap.add_argument('xml')
    ap.add_argument('--report', default='pin_audit.csv')
    args = ap.parse_args()
    csv_rows = load_csv(Path(args.csv))
    root, sym, phys = parse_xml(Path(args.xml))
    by_pos = {int(p['position']): p for p in sym}
    rows = []
    errors = []
    for pp in phys:
        pos = int(pp['position']); ball = pp['number']
        sp = by_pos.get(pos)
        if sp is None:
            errors.append(f'missing symbol pin at position {pos}')
            continue
        csv_row = next((r for r in csv_rows if r['ball']==ball), None)
        if csv_row is None:
            errors.append(f'ball {ball} not in CSV')
            continue
        xml_name = re.sub(r'_(\d+)$', '', sp.get('name','')) if csv_row['name'] == 'NC' else sp.get('name','')
        ok_name = (csv_row['name']=='NC' and xml_name=='NC') or (xml_name == csv_row['name']) or sp.get('name','').startswith(csv_row['name']+'_')
        nc_flag = None
        # Locate the IsNoConnect element for this symbol pin by position.
        # Re-find directly to avoid relying on XML tree parent references.
        # (ElementTree has no parent pointer; scan again.)
        for p in root.findall('.//Package/LibPart/NormalView/SymbolPinScalar'):
            d=p.find('Defn')
            if d is not None and int(d.attrib.get('position','-1'))==pos:
                nd=p.find('./IsNoConnect/Defn')
                nc_flag = nd.attrib.get('val') if nd is not None else None
                break
        expected_nc = '1' if csv_row['name']=='NC' else '0'
        ok_nc = (nc_flag == expected_nc)
        status = 'OK' if ok_name and ok_nc else 'ERROR'
        if status!='OK': errors.append(f'{ball}: name={sp.get("name")} expected={csv_row["name"]}, nc={nc_flag} expected={expected_nc}')
        rows.append([ball,csv_row['name'],sp.get('name',''),csv_row['bank'],csv_row['io_type'],nc_flag,status])
    with open(args.report,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['Ball','CSV Pin Name','XML Pin Name','Bank','I/O Type','XML IsNoConnect','Status']); w.writerows(rows)
    summary={'csv_package_pins':len(csv_rows),'xml_symbol_pins':len(sym),'xml_physical_pins':len(phys),'errors':len(errors),'xml_parse':True}
    print(json.dumps(summary,indent=2))
    if errors:
        for e in errors[:20]: print('ERROR:',e)
        raise SystemExit(1)

if __name__=='__main__': main()
