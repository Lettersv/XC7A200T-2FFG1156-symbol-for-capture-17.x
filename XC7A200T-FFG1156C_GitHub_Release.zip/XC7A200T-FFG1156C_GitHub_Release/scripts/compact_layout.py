#!/usr/bin/env python3
"""Generic helper for compacting an OrCAD library's pin-row spacing.

This script is intentionally conservative: it only changes SymbolPinScalar
Y coordinates and the four symbol-frame lines for a selected set of parts.
It does not change package-ball numbers, positions, or pin names.

It is a reference/reproducibility tool for the final cleanup stage; the
project's final XML remains the authoritative artifact.
"""
from __future__ import annotations
import argparse, xml.etree.ElementTree as ET
from pathlib import Path


def find_part(pkg, cell_name):
    for lp in pkg.findall('./LibPart'):
        d=lp.find('./Defn')
        if d is not None and d.attrib.get('CellName')==cell_name:
            return lp
    raise KeyError(cell_name)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('xml')
    ap.add_argument('--part', action='append', required=True)
    ap.add_argument('--spacing', type=int, default=10)
    args=ap.parse_args()
    tree=ET.parse(args.xml); root=tree.getroot(); pkg=root.find('.//Package')
    if pkg is None: raise SystemExit('Package not found')
    for name in args.part:
        part=find_part(pkg,name)
        nv=part.find('./NormalView')
        if nv is None: continue
        pins=[]
        for p in nv.findall('./SymbolPinScalar'):
            d=p.find('Defn')
            if d is not None: pins.append((p,d))
        # Preserve left/right ordering and only compress each side independently.
        groups={}
        for p,d in pins:
            x=int(d.attrib['startX']); groups.setdefault(x,[]).append((p,d))
        for items in groups.values():
            items.sort(key=lambda x:int(x[1].attrib['startY']))
            for i,(p,d) in enumerate(items):
                y=30+i*args.spacing
                for k in ('hotptY','startY'): d.attrib[k]=str(y)
        # Rebuild frame from actual min/max pin Y.
        ys=[int(d.attrib['startY']) for _,d in pins]
        if ys:
            y1=min(ys)-30; y2=max(ys)+20
            lines=nv.findall('./Line')
            if len(lines)>=4:
                # Keep current x extents from the first/second vertical lines.
                x2=int(nv.find('./SymbolBBox/Defn').attrib['x2']) if nv.find('./SymbolBBox/Defn') is not None else 300
                coords=[
                    {'x1':'0','x2':str(x2),'y1':str(y1),'y2':str(y1)},
                    {'x1':str(x2),'x2':str(x2),'y1':str(y2),'y2':str(y1)},
                    {'x1':str(x2),'x2':'0','y1':str(y2),'y2':str(y2)},
                    {'x1':'0','x2':'0','y1':str(y1),'y2':str(y2)},
                ]
                for line,c in zip(lines[:4],coords):
                    d=line.find('Defn'); d.attrib.update(c)
                bb=nv.find('./SymbolBBox/Defn')
                if bb is not None: bb.attrib.update({'y1':str(y1),'y2':str(y2)})
    tree.write(args.xml,encoding='UTF-8',xml_declaration=True)

if __name__=='__main__': main()
