#!/usr/bin/env python3
"""Reference tool for adding a visible bank label to each LibPart.

Uses an existing SymbolDisplayProp/PropFont pattern to avoid invalid Cadence
XML attributes. The label text is stored as user property 'FPGA Bank'.
"""
from __future__ import annotations
import argparse, xml.etree.ElementTree as ET


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('xml'); ap.add_argument('--font-height',type=int,default=26); args=ap.parse_args()
    tree=ET.parse(args.xml); root=tree.getroot(); pkg=root.find('.//Package');
    if pkg is None: raise SystemExit('Package not found')
    for lp in pkg.findall('./LibPart'):
        d=lp.find('./Defn'); nv=lp.find('./NormalView')
        if d is None or nv is None: continue
        cell=d.attrib.get('CellName','')
        bank=cell.split('_')[-1]
        if bank.startswith('GLOBAL') or bank.startswith('NC'):
            continue
        prop=nv.find("./SymbolDisplayProp[Defn[@name='FPGA Bank']]")
        if prop is None:
            prop=ET.SubElement(nv,'SymbolDisplayProp'); ET.SubElement(prop,'Defn',{'locX':'300','locY':'-35','name':'FPGA Bank','rotation':'0','textJustification':'1'})
            pf=ET.SubElement(prop,'PropFont'); ET.SubElement(pf,'Defn',{'escapement':'0','height':str(-abs(args.font_height)),'italic':'0','name':'Arial','orientation':'0','weight':'700','width':'4'})
            pc=ET.SubElement(prop,'PropColor'); ET.SubElement(pc,'Defn',{'val':'48'})
            pd=ET.SubElement(prop,'PropDispType'); ET.SubElement(pd,'Defn',{'ValueIfValueExist':'0','val':'1'})
        up=nv.find("./SymbolUserProp[Defn[@name='FPGA Bank']]")
        if up is None:
            up=ET.SubElement(nv,'SymbolUserProp')
            ET.SubElement(up,'Defn',{'name':'FPGA Bank','val':bank.replace('BANK','bank-').lower()})
    tree.write(args.xml,encoding='UTF-8',xml_declaration=True)

if __name__=='__main__': main()
