# Project notes / iteration summary

The library was refined through repeated comparison against the official FFG1156 package database and visual inspection in Cadence.

### Key milestones

- Initial XML vs package CSV comparison: physical mapping found complete; NC semantics were missing.
- Corrected NC flags for the 100 official NC package positions.
- Split the large FPGA into bank-oriented heterogeneous parts.
- Added visible bank labels.
- Tightened symbol frames and row spacing.
- Grouped differential P/N signals and related functional signals.
- Reorganized GTP RX/TX with lane-wise horizontal alignment.
- Split large global/GND/NC groups into additional parts.
- Final global row spacing reduced from 13 to 10.

The attached screenshots in `docs/screenshots/` are examples supplied during the visual review process.
