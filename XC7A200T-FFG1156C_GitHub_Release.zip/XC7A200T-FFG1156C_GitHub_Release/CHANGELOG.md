# Changelog

## v13 — final shared result
- 24 heterogeneous parts.
- All package balls retained.
- 100 official NC positions marked as no-connect.
- Bank-oriented partitioning retained.
- Differential P/N pairs grouped vertically.
- GTP RX/TX arranged on opposite sides with lane-wise horizontal alignment.
- Requested Part-A configuration/control signal order applied.
- General pin-row spacing reduced to 10 coordinate units.
- Compact top/bottom margins retained.

## v12
- Part-A right-side signal order explicitly set to the requested sequence.

## v11
- General pin spacing set to 13.
- Top/bottom blank margins reduced.

## v10
- GND Part-T/Part-U row spacing reduced to approximately 2/3 of the prior spacing.

## v9 / v8
- GTP RX/TX side assignment and horizontal alignment refined.
- GND and NC groups split to reduce symbol height.

## v7 and earlier
- Global/power/NC groups progressively split and bank-oriented layout refined.
- Differential-pair grouping introduced and compact frames corrected.
